---
name: Grandmaster Heritage
colors:
  surface: '#121316'
  surface-dim: '#121316'
  surface-bright: '#38393c'
  surface-container-lowest: '#0d0e11'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#292a2d'
  surface-container-highest: '#343538'
  on-surface: '#e3e2e6'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e3e2e6'
  inverse-on-surface: '#303034'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#cec6b5'
  on-secondary: '#343024'
  secondary-container: '#4b4639'
  on-secondary-container: '#bcb4a4'
  tertiary: '#ffbec1'
  on-tertiary: '#65061c'
  tertiary-container: '#ff949c'
  on-tertiary-container: '#821f2f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#eae2d0'
  secondary-fixed-dim: '#cec6b5'
  on-secondary-fixed: '#1f1b10'
  on-secondary-fixed-variant: '#4b4639'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b6'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#842131'
  background: '#121316'
  on-background: '#e3e2e6'
  surface-variant: '#343538'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 44px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  notation-lg:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.02em
  notation-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 2rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system balances historical gravitas with rigorous, contemporary digital editorial craftsmanship. Designed for immersive chess scrollytelling, narrative deep-dives, and archival master game analysis, the aesthetic marries classic print editorial traditions with hyper-precise data presentation.

The visual style is **High-Contrast Editorial & Tactile Precision**:
- **Atmospheric & Scholarly**: Rich obsidian depths evoking private grandmaster archives, dimly lit tournament halls, and weighted wood pieces.
- **Analytical Clarity**: Surgical algebraic chess notation paired with clean body text, guaranteeing maximum legibility during complex multi-ply move analysis.
- **Refined Materiality**: Restrained warm gold foil accents, tactile border rules, and ivory-and-ebony surfaces that feel physical yet digital-first.

## Colors

The palette is anchored by the deep obsidian tone of tournament ebony and illuminated by warm archival golds and ivory parchment:

- **Primary (`#D4AF37` / Imperial Gold)**: Used sparingly for high-value focal moments, historical triumph markers, current move evaluations, key move plies, and active chapter indicators.
- **Secondary (`#F4EBD9` / Polished Ivory)**: Represents the light board squares, high-legibility typographic highlights, and primary contrast elements against dark surfaces.
- **Tertiary (`#8B2635` / Crimson Blunder)**: Reserved for analytical tension, tactical inaccuracies, forfeits, and critical evaluation drops.
- **Neutral (`#0D0E11` / Deep Obsidian)**: The default background foundation, providing an ink-deep, reflection-free surface for focus.

### Functional Variations & Inverted Mode
- **Board Light Square**: `#EFE6D5`
- **Board Dark Square**: `#2A2B30`
- **Move Highlight / Path**: `rgba(212, 175, 55, 0.22)`
- **Surface Elevation Dark**: Tier 1 (`#14161B`), Tier 2 (`#1B1E25`), Tier 3 (`#232731`)
- **Inverted Light Mode**: The background becomes `#FAF7F2` (cream vellum), surfaces scale from `#FFFFFF` to `#F0EDE6`, while primary typography shifts to `#121316` and dark squares adjust to `#4A4C54`.

## Typography

The typographic hierarchy relies on a calculated pairing of three distinct typefaces:

1. **Playfair Display**: Delivers editorial grace, literary authority, and historical scale for game titles, tournament chronicles, and grandmaster quotes. Italicized styles are favored for narrative commentary and chapter subtitles.
2. **Inter**: Handles all long-form narrative prose and critical essay text. Its neutral, systematic geometry prevents reading fatigue and creates an unobtrusive counterweight to the serif headings.
3. **JetBrains Mono**: Strictly governs algebraic notation (e.g., `24. Qxd5+ exd5`), clock timers, engine evaluations (`+1.42`), ply counters, board coordinates, and technical metadata.

## Layout & Spacing

The architecture is engineered around the **Dual-Canvas Scrollytelling Paradigm**:

- **Desktop (>= 1024px)**: Asymmetric split layout. A pinned 50vw viewport holds the interactive 64-square chessboard and coordinate HUD, remaining fixed as the user scrolls. The scrolling 50vw column presents historical narrative beats, move triggers, archival photography, and analysis diagrams.
- **Tablet (768px – 1023px)**: The board pins to the top third of the viewport (`sticky top-0`) while narrative cards scroll beneath it with condensed annotations.
- **Mobile (< 768px)**: Stacked single-column flow with a docked mini-board overlay that expands upon tapping an active ply notation.
- **Rhythm**: All structural gaps and component interiors scale via the `space-*` system, enforcing clear negative margins between narrative paragraphs and analytical ply blocks.

## Elevation & Depth

Visual hierarchy uses **Tonal Layering** paired with **Low-Contrast Hairline Framing** to honor the craft of traditional chess boards:

- **Surface Base**: Ground level is pure obsidian (`#0D0E11`).
- **Surface Elevation (Cards, Panels, Menus)**: Achieved via `#14161B` with an inset `1px` border of `rgba(244, 235, 217, 0.08)`.
- **Active Board & Interactive Floating Triggers**: Raised using ambient depth—shadows carry an obsidian tone with a subtle warm tint: `0 16px 36px -8px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(212, 175, 55, 0.25)`.
- **Glass Accent Layers**: Navigation headers and modal analytical panels utilize backdrop filters (`backdrop-blur-md` with `rgba(13, 14, 17, 0.85)`).

## Shapes

The shape system adopts a **Slightly Softened Architectural** aesthetic (`roundedness: 1`):
- Standard cards, interactive ply pills, and navigation blocks use subtle `4px` (`0.25rem`) rounded corners, matching the milled precision of competition wooden board bevels.
- Dialogs and media containers cap at `8px` (`0.5rem`).
- The 64 squares within the chessboard retain absolute crispness (`0px`) to preserve geometric line continuity across rank and file divisions.

## Components

### 1. Interactive Chessboard & Squares
- **Container**: Framed with a 12px outer wood-matte border (`#1B1E25`) marked with unobtrusive rank/file coordinates in `label-caps` (`#7B7F8D`).
- **Squares**: Ivory `#EFE6D5` and Obsidian-slate `#2A2B30`. Active piece highlights apply `rgba(212, 175, 55, 0.28)`.
- **Last Move Markers**: Discrete 4px circular indicators or hairline halos; no garish arrows unless entering deep analysis mode.

### 2. Move Ply Chips & Notation Tracks
- **Move Chip**: Rendered in `notation-md`. Default background is `rgba(244, 235, 217, 0.05)` with `1px` solid `rgba(244, 235, 217, 0.1)`.
- **Interactive State**: Clicking or scrolling to a ply turns the chip into an active state with a warm gold fill (`#D4AF37`), dark ink text (`#0D0E11`), and an accompanying move-sound cue.
- **Evaluation Badge**: Monospace chips displaying stockfish engine scores (e.g. `+2.8`) with green or red indicator dots.

### 3. Scrollytelling Narrative Cards
- **Structure**: Generous vertical padding (`space-xl`), crisp top separator hairline in `rgba(212, 175, 55, 0.2)`.
- **Typography Sequence**: Chapter label in `label-caps` (Imperial Gold) → Move header in `headline-md` → Literary critique in `body-lg`.
- **Trigger Zones**: Intersection observers monitor viewport middle (`50%`) to automatically advance the board position smoothly using easing curves (`cubic-bezier(0.2, 0, 0, 1)`).

### 4. Buttons & Controls
- **Primary Action (e.g., "Analyze Line")**: Solid Imperial Gold (`#D4AF37`) background, dark obsidian text (`#0D0E11`), `4px` radius, bold letter-spaced mono font. Hover introduces a luminous gold ambient glow.
- **Secondary Action (e.g., "Flip Board", "Download PGN")**: Ghost button with `1px` border of `rgba(244, 235, 217, 0.25)` and ivory text.

### 5. Timeline & Chapter Navigation
- Pinned vertical rail with delicate gold step nodes. Active chapter connects via a radiant vertical line, with completed chapters muted at 40% opacity.