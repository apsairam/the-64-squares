import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { SET_PROFILES } from './set-profiles.js';

const FRAMES = 72;
const COLS = 6;
const ROWS = 12;
const CELL_W = 420;
const CELL_H = 525;
const TYPES = ['pawn', 'knight', 'bishop', 'rook', 'queen', 'king'];

const TARGET_HEIGHT = {
  pawn: 1.72,
  knight: 1.98,
  bishop: 2.03,
  rook: 1.9,
  queen: 2.07,
  king: 2.15,
};

const START_ANGLE = {
  pawn: 0.24,
  knight: -0.34,
  bishop: 0.24,
  rook: 0.2,
  queen: 0.18,
  king: 0.18,
};

// The knight's strongest read is its profile. Rotate the frame order so the
// turntable opens on that view while keeping the same studio reflections.
const FRAME_OFFSET = {
  knight: 36,
};

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  alpha: true,
  preserveDrawingBuffer: true,
});
renderer.setPixelRatio(1);
renderer.setSize(CELL_W, CELL_H, false);
renderer.setClearColor(0x000000, 0);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.02;

const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);

function studioEnvironment() {
  const env = new THREE.Scene();
  env.background = new THREE.Color(0x000000);

  const panel = (width, height, color, intensity, position, rotation) => {
    const material = new THREE.MeshBasicMaterial({
      color: new THREE.Color(color).multiplyScalar(intensity),
      side: THREE.DoubleSide,
    });
    material.toneMapped = false;
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height), material);
    mesh.position.copy(position);
    mesh.rotation.set(...rotation);
    env.add(mesh);
  };

  // Broad overhead wash.
  panel(14, 14, 0xffffff, 0.48, new THREE.Vector3(0, 7, 0), [Math.PI / 2, 0, 0]);
  // Two large softboxes make the broad white reflections in the supplied set.
  panel(5, 10, 0xffffff, 2.4, new THREE.Vector3(-4.6, 3.4, 3.2), [0, Math.PI / 3, 0]);
  panel(4, 9, 0xffffff, 1.8, new THREE.Vector3(4.4, 3, 3), [0, -Math.PI / 3, 0]);
  // Broad frontal strips put a long white reflection down the front-left.
  panel(2.2, 8, 0xffffff, 3.1, new THREE.Vector3(-2.8, 2.8, 4.6), [0, -0.3, 0]);
  panel(1.6, 7, 0xffffff, 1.7, new THREE.Vector3(2.9, 2.3, 4.4), [0, 0.3, 0]);
  // Bright back wall and a soft front fill keep the chrome from going black.
  panel(10, 8, 0xffffff, 1.3, new THREE.Vector3(0, 3, -5.2), [0, 0, 0]);
  panel(9, 5, 0xffffff, 0.82, new THREE.Vector3(0, 2.2, 6), [0, 0, 0]);
  // A crisp strip adds the long specular line seen on the reference renders.
  panel(1.2, 7, 0xffffff, 2.8, new THREE.Vector3(-3.6, 2.8, 1.6), [0, Math.PI / 2, 0]);

  return pmrem.fromScene(env, 0.025).texture;
}

scene.environment = studioEnvironment();
scene.environmentIntensity = 1.38;

const camera = new THREE.PerspectiveCamera(23, CELL_W / CELL_H, 0.1, 40);
camera.position.set(0, 2.18, 7.35);
camera.lookAt(0, 1.03, 0);

const key = new THREE.DirectionalLight(0xfff4e4, 2.7);
key.position.set(4.2, 7.2, 5.2);
scene.add(key);

const fill = new THREE.DirectionalLight(0xc4d6ff, 0.9);
fill.position.set(-5.4, 3.2, 3.6);
scene.add(fill);

const rim = new THREE.DirectionalLight(0xffffff, 4.2);
rim.position.set(-4.1, 5.1, -5.2);
scene.add(rim);

const rimWarm = new THREE.DirectionalLight(0xffe5c8, 1.7);
rimWarm.position.set(4.4, 2.2, -4.6);
scene.add(rimWarm);

const baseMaterial = new THREE.MeshPhysicalMaterial({
  color: 0xffffff,
  metalness: 1,
  roughness: 0.17,
  clearcoat: 0.6,
  clearcoatRoughness: 0.12,
  envMapIntensity: 1.5,
  vertexColors: true,
});

const trimMaterial = new THREE.MeshPhysicalMaterial({
  color: 0xc4c4c9,
  metalness: 1,
  roughness: 0.06,
  clearcoat: 0.8,
  clearcoatRoughness: 0.07,
  envMapIntensity: 1.8,
});

const darkChromeMaterial = new THREE.MeshPhysicalMaterial({
  color: 0x1d1d21,
  metalness: 0.92,
  roughness: 0.3,
  clearcoat: 0.35,
  clearcoatRoughness: 0.2,
  envMapIntensity: 1.0,
});

const cavityMaterial = new THREE.MeshStandardMaterial({
  color: 0x030304,
  metalness: 0.15,
  roughness: 0.85,
  side: THREE.DoubleSide,
});

const darkMaterial = new THREE.MeshStandardMaterial({
  color: 0x050506,
  metalness: 0.55,
  roughness: 0.4,
  side: THREE.DoubleSide,
});

const bottomTone = new THREE.Color(0x2d2d32);
const topTone = new THREE.Color(0x9a9aa2);

function applyGradient(geometry, yOffset = 0) {
  const positions = geometry.attributes.position;
  const colors = new Float32Array(positions.count * 3);
  const color = new THREE.Color();
  for (let index = 0; index < positions.count; index += 1) {
    const t = THREE.MathUtils.clamp(positions.getY(index) + yOffset, 0, 1);
    color.copy(bottomTone).lerp(topTone, Math.pow(t, 0.82));
    colors[index * 3] = color.r;
    colors[index * 3 + 1] = color.g;
    colors[index * 3 + 2] = color.b;
  }
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  return geometry;
}

function bodyMesh(geometry, yOffset = 0) {
  return new THREE.Mesh(applyGradient(geometry, yOffset), baseMaterial);
}

function bodyFromProfile(points) {
  const vectors = points.map(([radius, y]) => new THREE.Vector2(radius, y));
  return bodyMesh(new THREE.LatheGeometry(vectors, 96));
}

let knightFaceTexture = null;

function createKnightHeadTexture(image) {
  const meta = SET_PROFILES.knight.image;
  const points = SET_PROFILES.knight.head;
  const xs = points.map(([x]) => x);
  const ys = points.map(([, y]) => y);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);

  const left = Math.max(0, Math.floor(meta.axisX + minX * meta.bboxHeight));
  const right = Math.min(
    meta.width,
    Math.ceil(meta.axisX + maxX * meta.bboxHeight)
  );
  const top = Math.max(0, Math.floor(meta.bottom - maxY * meta.bboxHeight));
  const bottom = Math.min(
    meta.height,
    Math.ceil(meta.bottom - minY * meta.bboxHeight)
  );

  const canvas = document.createElement('canvas');
  canvas.width = right - left;
  canvas.height = bottom - top;
  const context = canvas.getContext('2d');
  context.drawImage(
    image,
    left,
    top,
    right - left,
    bottom - top,
    0,
    0,
    canvas.width,
    canvas.height
  );

  const result = context.getImageData(0, 0, canvas.width, canvas.height);
  const data = result.data;
  for (let index = 0; index < data.length; index += 4) {
    const alpha = data[index + 3] / 255;
    if (alpha <= 0.015) {
      data[index + 3] = 0;
      data[index] = 0;
      data[index + 1] = 0;
      data[index + 2] = 0;
      continue;
    }
    if (alpha < 0.985) {
      data[index] = Math.max(0, Math.min(255, (data[index] - 255 * (1 - alpha)) / alpha));
      data[index + 1] = Math.max(0, Math.min(255, (data[index + 1] - 255 * (1 - alpha)) / alpha));
      data[index + 2] = Math.max(0, Math.min(255, (data[index + 2] - 255 * (1 - alpha)) / alpha));
    }
  }
  context.putImageData(result, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
  texture.needsUpdate = true;
  return texture;
}

function radiusAt(points, y) {
  let radius = 0;
  for (const [candidate, height] of points) {
    if (height > y) break;
    radius = candidate;
  }
  return radius;
}

function trimRing(group, radius, tube, y) {
  if (radius <= 0) return null;
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(radius, tube, 14, 96),
    trimMaterial
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.y = y;
  group.add(ring);
  return ring;
}

function addBeadRing(group, radius, y, count, bead) {
  const geometry = new THREE.SphereGeometry(bead, 12, 10);
  for (let index = 0; index < count; index += 1) {
    const angle = (index / count) * Math.PI * 2;
    const mesh = new THREE.Mesh(geometry, trimMaterial);
    mesh.position.set(
      Math.cos(angle) * radius,
      y,
      Math.sin(angle) * radius
    );
    group.add(mesh);
  }
}

function addBaseTrim(group, points, cut) {
  const levels = [0.032, 0.09, 0.15];
  levels.forEach((level, index) => {
    if (level >= cut - 0.02) return;
    trimRing(
      group,
      radiusAt(points, level),
      index === 0 ? 0.006 : 0.005,
      level
    );
  });
  if (cut > 0.12) {
    addBeadRing(
      group,
      radiusAt(points, 0.105) * 1.003,
      0.105,
      40,
      0.0042
    );
  }
  if (cut > 0.2) {
    trimRing(group, radiusAt(points, 0.195), 0.004, 0.195);
  }
}

function addCylinder(group, radius, height, y, material = darkMaterial) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, height, 72, 1, true),
    material
  );
  mesh.position.y = y;
  group.add(mesh);
  return mesh;
}

function addDisc(group, radius, y, material = darkMaterial) {
  const mesh = new THREE.Mesh(new THREE.CircleGeometry(radius, 72), material);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = y;
  group.add(mesh);
  return mesh;
}

function buildPawn() {
  const group = new THREE.Group();
  const points = SET_PROFILES.pawn.points;
  group.add(bodyFromProfile(points));
  addBaseTrim(group, points, 1);
  trimRing(group, radiusAt(points, 0.29), 0.006, 0.29);
  trimRing(group, radiusAt(points, 0.775), 0.004, 0.775);
  addBeadRing(group, radiusAt(points, 0.79) * 1.02, 0.79, 28, 0.0055);
  return group;
}

function buildRook() {
  const group = new THREE.Group();
  const profile = SET_PROFILES.rook;
  const points = profile.points;
  group.add(bodyFromProfile(points));
  addBaseTrim(group, points, profile.cut);
  trimRing(group, radiusAt(points, 0.26), 0.006, 0.26);
  trimRing(group, radiusAt(points, 0.31), 0.005, 0.31);
  trimRing(group, radiusAt(points, 0.785), 0.011, 0.785);

  const innerRadius = radiusAt(points, 0.78) * 0.79;
  addCylinder(group, innerRadius, 0.2, 0.885, cavityMaterial);
  addDisc(group, innerRadius, 0.8, cavityMaterial);

  const merlonGeometry = new RoundedBoxGeometry(0.062, 0.2, 0.08, 3, 0.01);
  const capGeometry = new RoundedBoxGeometry(0.05, 0.008, 0.062, 2, 0.003);
  const merlonRadius = 0.165;
  for (let index = 0; index < 8; index += 1) {
    const angle = (index / 8) * Math.PI * 2;
    const merlon = new THREE.Mesh(merlonGeometry.clone(), darkChromeMaterial);
    merlon.position.set(
      Math.cos(angle) * merlonRadius,
      0.895,
      Math.sin(angle) * merlonRadius
    );
    merlon.rotation.y = -angle;
    group.add(merlon);

    const cap = new THREE.Mesh(capGeometry, trimMaterial);
    cap.position.set(
      Math.cos(angle) * merlonRadius,
      0.997,
      Math.sin(angle) * merlonRadius
    );
    cap.rotation.y = -angle;
    group.add(cap);
  }
  return group;
}

function buildBishop() {
  const group = new THREE.Group();
  const points = SET_PROFILES.bishop.points;
  group.add(bodyFromProfile(points));
  addBaseTrim(group, points, 1);
  trimRing(group, radiusAt(points, 0.58), 0.005, 0.58);
  trimRing(group, radiusAt(points, 0.68), 0.005, 0.68);
  trimRing(group, radiusAt(points, 0.775), 0.005, 0.775);

  const slash = [
    [-0.072, 0.665],
    [-0.035, 0.725],
    [0.012, 0.795],
    [0.061, 0.862],
  ];
  [1, -1].forEach((side) => {
    const curvePoints = slash.map(([x, y]) => {
      const radius = radiusAt(points, y);
      const z = Math.sqrt(Math.max(radius * radius - x * x, 0)) * side;
      return new THREE.Vector3(x, y, z);
    });
    const curve = new THREE.CatmullRomCurve3(curvePoints);
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(curve, 28, 0.012, 8, false),
        darkMaterial
      )
    );

    const edgePoints = slash.map(([x, y]) => {
      const shiftedX = x + 0.015 * side;
      const radius = radiusAt(points, y);
      const z =
        Math.sqrt(Math.max(radius * radius - shiftedX * shiftedX, 0)) *
        side *
        1.008;
      return new THREE.Vector3(shiftedX, y, z);
    });
    const edge = new THREE.CatmullRomCurve3(edgePoints);
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(edge, 28, 0.0032, 6, false),
        trimMaterial
      )
    );
  });
  return group;
}

function crossShape() {
  const shape = new THREE.Shape();
  shape.moveTo(-0.024, 0.095);
  shape.lineTo(0.024, 0.095);
  shape.lineTo(0.024, 0.028);
  shape.lineTo(0.095, 0.028);
  shape.lineTo(0.095, -0.028);
  shape.lineTo(0.024, -0.028);
  shape.lineTo(0.024, -0.095);
  shape.lineTo(-0.024, -0.095);
  shape.lineTo(-0.024, -0.028);
  shape.lineTo(-0.095, -0.028);
  shape.lineTo(-0.095, 0.028);
  shape.lineTo(-0.024, 0.028);
  shape.closePath();
  return shape;
}

function buildQueen() {
  const group = new THREE.Group();
  const profile = SET_PROFILES.queen;
  const points = profile.points;
  group.add(bodyFromProfile(points));
  addBaseTrim(group, points, profile.cut);
  trimRing(group, radiusAt(points, 0.62), 0.005, 0.62);
  trimRing(group, radiusAt(points, 0.71), 0.005, 0.71);
  trimRing(group, radiusAt(points, 0.776), 0.007, 0.776);

  const cupPoints = [
    [0.094, 0.775],
    [0.106, 0.8],
    [0.122, 0.84],
    [0.142, 0.875],
    [0.155, 0.888],
  ].map(([radius, y]) => new THREE.Vector2(radius, y));
  group.add(bodyMesh(new THREE.LatheGeometry(cupPoints, 96)));

  const innerPoints = [
    [0.145, 0.886],
    [0.133, 0.868],
    [0.114, 0.838],
    [0.098, 0.8],
    [0.09, 0.777],
  ].map(([radius, y]) => new THREE.Vector2(radius, y));
  const inner = new THREE.Mesh(
    new THREE.LatheGeometry(innerPoints, 96),
    darkMaterial
  );
  inner.material.side = THREE.DoubleSide;
  group.add(inner);

  const rimPoints = [];
  for (let index = 0; index < 144; index += 1) {
    const angle = (index / 144) * Math.PI * 2;
    const radius = 0.155;
    rimPoints.push(
      new THREE.Vector3(
        Math.cos(angle) * radius,
        0.888 + Math.cos(angle * 9) * 0.015,
        Math.sin(angle) * radius
      )
    );
  }
  const rimCurve = new THREE.CatmullRomCurve3(rimPoints, true);
  group.add(
    new THREE.Mesh(
      new THREE.TubeGeometry(rimCurve, 240, 0.0065, 8, true),
      trimMaterial
    )
  );

  const finial = [
    [0.031, 0.912],
    [0.024, 0.952],
    [0.017, 0.984],
  ];
  finial.forEach(([radius, y]) => {
    group.add(bodyMesh(new THREE.SphereGeometry(radius, 32, 20), y));
  });
  group.children.slice(-3).forEach((ball, index) => {
    ball.position.y = finial[index][1];
  });
  const tip = bodyMesh(new THREE.SphereGeometry(0.009, 20, 14), 1);
  tip.position.y = 1.0;
  group.add(tip);
  return group;
}

function buildKing() {
  const group = new THREE.Group();
  const profile = SET_PROFILES.king;
  const points = profile.points;
  group.add(bodyFromProfile(points));
  addBaseTrim(group, points, profile.cut);
  trimRing(group, radiusAt(points, 0.57), 0.005, 0.57);
  trimRing(group, radiusAt(points, 0.735), 0.005, 0.735);
  trimRing(group, radiusAt(points, 0.795), 0.006, 0.795);

  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(0.082, 48, 24, 0, Math.PI * 2, 0, Math.PI / 2),
    baseMaterial
  );
  dome.position.y = 0.805;
  applyGradient(dome.geometry, 0.805);
  group.add(dome);

  const geometry = new THREE.ExtrudeGeometry(crossShape(), {
    depth: 0.052,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 3,
    curveSegments: 4,
  });
  geometry.translate(0, 0, -0.026);

  const cross = new THREE.Mesh(geometry, trimMaterial);
  cross.position.set(0, 0.925, 0.001);
  group.add(cross);

  const finial = new THREE.Mesh(
    new THREE.SphereGeometry(0.011, 20, 14),
    trimMaterial
  );
  finial.position.y = 1.018;
  group.add(finial);
  return group;
}

function createKnightHead(points) {
  const xs = points.map(([x]) => x);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const range = maxX - minX;
  const SECTIONS = 104;
  const RADIAL = 48;
  const raw = [];

  for (let index = 0; index < SECTIONS; index += 1) {
    const x = minX + ((index + 0.5) / SECTIONS) * range;
    let bottom = Infinity;
    let top = -Infinity;
    let found = false;
    for (let edge = 0; edge < points.length; edge += 1) {
      const [x1, y1] = points[edge];
      const [x2, y2] = points[(edge + 1) % points.length];
      if (Math.abs(x2 - x1) < 1e-9) continue;
      const t = (x - x1) / (x2 - x1);
      if (t < 0 || t > 1) continue;
      const y = y1 + (y2 - y1) * t;
      bottom = Math.min(bottom, y);
      top = Math.max(top, y);
      found = true;
    }
    raw.push(found ? [bottom, top] : null);
  }

  const spans = raw.map((span, index) => {
    if (!span) return null;
    let bottom = 0;
    let top = 0;
    let count = 0;
    for (let offset = -2; offset <= 2; offset += 1) {
      const neighbour = raw[index + offset];
      if (!neighbour) continue;
      bottom += neighbour[0];
      top += neighbour[1];
      count += 1;
    }
    return [bottom / count, top / count];
  });

  const sections = [];
  for (let index = 0; index < SECTIONS; index += 1) {
    const span = spans[index];
    if (!span) continue;
    const [bottom, top] = span;
    if (top - bottom < 0.025) continue;
    const t = (minX + ((index + 0.5) / SECTIONS) * range - minX) / range;
    const halfWidth =
      0.055 + 0.108 * Math.sin(Math.PI * Math.pow(t, 0.72)) + 0.018 * t;
    sections.push({
      x: minX + ((index + 0.5) / SECTIONS) * range,
      cy: (top + bottom) / 2,
      hh: (top - bottom) / 2,
      hw: halfWidth,
    });
  }

  const positions = [];
  const indices = [];
  const ringStarts = [];
  sections.forEach((section) => {
    ringStarts.push(positions.length / 3);
    for (let radial = 0; radial < RADIAL; radial += 1) {
      const theta = (radial / RADIAL) * Math.PI * 2;
      const sine = Math.sin(theta);
      const cosine = Math.cos(theta);
      const y =
        Math.sign(sine) * Math.pow(Math.abs(sine), 0.82) * section.hh +
        section.cy;
      const z = Math.sign(cosine) * Math.pow(Math.abs(cosine), 0.82) * section.hw;
      positions.push(section.x, y, z);
    }
  });

  for (let section = 0; section < sections.length - 1; section += 1) {
    const a = ringStarts[section];
    const b = ringStarts[section + 1];
    for (let radial = 0; radial < RADIAL; radial += 1) {
      const next = (radial + 1) % RADIAL;
      indices.push(a + radial, b + radial, a + next);
      indices.push(a + next, b + radial, b + next);
    }
  }

  const frontRing = ringStarts[0];
  const backRing = ringStarts[ringStarts.length - 1];
  const front = sections[0];
  const back = sections[sections.length - 1];
  const frontCentre = positions.length / 3;
  positions.push(front.x - 0.002, front.cy, 0);
  const backCentre = positions.length / 3;
  positions.push(back.x + 0.002, back.cy, 0);
  for (let radial = 0; radial < RADIAL; radial += 1) {
    const next = (radial + 1) % RADIAL;
    indices.push(frontCentre, frontRing + radial, frontRing + next);
    indices.push(backCentre, backRing + next, backRing + radial);
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(positions, 3)
  );
  geometry.setIndex(indices);
  geometry.computeVertexNormals();

  return { mesh: bodyMesh(geometry), sections };
}

function knightSection(sections, x) {
  let best = sections[0];
  let distance = Infinity;
  sections.forEach((section) => {
    const next = Math.abs(section.x - x);
    if (next < distance) {
      best = section;
      distance = next;
    }
  });
  return best;
}

function knightSurfaceZ(section, y) {
  const normalised = THREE.MathUtils.clamp(
    (y - section.cy) / section.hh,
    -1,
    1
  );
  const term = Math.max(
    0,
    1 - Math.pow(Math.abs(normalised), 2.44)
  );
  return section.hw * Math.pow(term, 0.41);
}

function buildKnight() {
  const group = new THREE.Group();
  const profile = SET_PROFILES.knight;
  const points = profile.base;
  group.add(bodyFromProfile(points));
  addBaseTrim(group, points, profile.cut);
  trimRing(group, radiusAt(points, 0.198), 0.008, 0.198);

  const { mesh: head, sections } = createKnightHead(profile.head);
  group.add(head);

  if (knightFaceTexture) {
    const xs = profile.head.map(([x]) => x);
    const ys = profile.head.map(([, y]) => y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);
    const geometry = new THREE.PlaneGeometry(maxX - minX, maxY - minY);
    const material = new THREE.MeshBasicMaterial({
      map: knightFaceTexture,
      transparent: true,
      alphaTest: 0.04,
      side: THREE.FrontSide,
      toneMapped: false,
    });
    const front = new THREE.Mesh(geometry, material);
    front.position.set((minX + maxX) / 2, (minY + maxY) / 2, 0.19);
    group.add(front);

    const back = new THREE.Mesh(geometry, material);
    back.position.set((minX + maxX) / 2, (minY + maxY) / 2, -0.19);
    back.rotation.y = Math.PI;
    group.add(back);

  }

  // Eyes, nostrils and their tiny silver catchlights.
  const eyeX = -0.16;
  const eyeY = 0.755;
  const eyeSection = knightSection(sections, eyeX);
  const eyeZ = knightSurfaceZ(eyeSection, eyeY) * 0.88;
  const nostrilX = -0.305;
  const nostrilY = 0.615;
  const nostrilSection = knightSection(sections, nostrilX);
  const nostrilZ = knightSurfaceZ(nostrilSection, nostrilY) * 0.72;

  [1, -1].forEach((side) => {
    const socket = new THREE.Mesh(
      new THREE.SphereGeometry(0.019, 20, 14),
      darkMaterial
    );
    socket.scale.z = 0.55;
    socket.position.set(eyeX, eyeY, side * eyeZ);
    group.add(socket);

    const glint = new THREE.Mesh(
      new THREE.SphereGeometry(0.006, 14, 10),
      trimMaterial
    );
    glint.position.set(eyeX - 0.002, eyeY + 0.007, side * (eyeZ + 0.009));
    group.add(glint);

    const nostril = new THREE.Mesh(
      new THREE.SphereGeometry(0.011, 16, 12),
      darkMaterial
    );
    nostril.scale.z = 0.55;
    nostril.position.set(nostrilX, nostrilY, side * nostrilZ);
    group.add(nostril);
  });

  return group;
}

const BUILDERS = {
  pawn: buildPawn,
  knight: buildKnight,
  bishop: buildBishop,
  rook: buildRook,
  queen: buildQueen,
  king: buildKing,
};

function preparePiece(type) {
  const group = BUILDERS[type]();
  const bounds = new THREE.Box3().setFromObject(group);
  const size = bounds.getSize(new THREE.Vector3());
  const scale = TARGET_HEIGHT[type] / size.y;
  group.scale.setScalar(scale);

  const scaledBounds = new THREE.Box3().setFromObject(group);
  const center = scaledBounds.getCenter(new THREE.Vector3());
  group.position.set(-center.x, 1.03 - center.y, -center.z);
  return group;
}

const sheetCanvas = document.createElement('canvas');
sheetCanvas.width = CELL_W * COLS;
sheetCanvas.height = CELL_H * ROWS;
const sheetContext = sheetCanvas.getContext('2d');

function renderSheet(type) {
  scene.clear();
  scene.add(key, fill, rim, rimWarm);
  const piece = preparePiece(type);
  scene.add(piece);

  sheetContext.clearRect(0, 0, sheetCanvas.width, sheetCanvas.height);

  const offset = FRAME_OFFSET[type] ?? 0;
  for (let frame = 0; frame < FRAMES; frame += 1) {
    const angle =
      START_ANGLE[type] +
      (((frame + offset) % FRAMES) / FRAMES) * Math.PI * 2;
    piece.rotation.y = angle;

    renderer.clear();
    renderer.render(scene, camera);

    const column = frame % COLS;
    const row = Math.floor(frame / COLS);
    sheetContext.drawImage(
      renderer.domElement,
      column * CELL_W,
      row * CELL_H,
      CELL_W,
      CELL_H
    );
  }

  scene.remove(piece);
  piece.traverse((child) => {
    if (child.isMesh) child.geometry.dispose();
  });

  return sheetCanvas.toDataURL('image/webp', 0.9);
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`Could not load ${source}`));
    image.src = source;
  });
}

function setStill(image) {
  const source = document.createElement('canvas');
  source.width = image.naturalWidth;
  source.height = image.naturalHeight;
  const sourceContext = source.getContext('2d');
  sourceContext.drawImage(image, 0, 0);
  const pixels = sourceContext.getImageData(0, 0, source.width, source.height);
  const data = pixels.data;

  let minX = source.width;
  let minY = source.height;
  let maxX = 0;
  let maxY = 0;
  for (let y = 0; y < source.height; y += 1) {
    for (let x = 0; x < source.width; x += 1) {
      if (data[(y * source.width + x) * 4 + 3] > 8) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  const cropW = maxX - minX + 1;
  const cropH = maxY - minY + 1;
  const targetH = 720;
  const targetW = Math.max(1, Math.round((cropW / cropH) * targetH));
  const output = document.createElement('canvas');
  output.width = targetW;
  output.height = targetH;
  const context = output.getContext('2d');
  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = 'high';
  context.drawImage(
    image,
    minX,
    minY,
    cropW,
    cropH,
    0,
    0,
    targetW,
    targetH
  );

  // The source renders were made on white, so anti-aliased edges carry a
  // white fringe. Un-premultiply against white so the chrome sits cleanly
  // on the site's near-black background.
  const result = context.getImageData(0, 0, targetW, targetH);
  const out = result.data;
  for (let index = 0; index < out.length; index += 4) {
    const alpha = out[index + 3] / 255;
    if (alpha <= 0.015) {
      out[index + 3] = 0;
      out[index] = 0;
      out[index + 1] = 0;
      out[index + 2] = 0;
      continue;
    }
    if (alpha < 0.985) {
      out[index] = Math.max(
        0,
        Math.min(255, (out[index] - 255 * (1 - alpha)) / alpha)
      );
      out[index + 1] = Math.max(
        0,
        Math.min(255, (out[index + 1] - 255 * (1 - alpha)) / alpha)
      );
      out[index + 2] = Math.max(
        0,
        Math.min(255, (out[index + 2] - 255 * (1 - alpha)) / alpha)
      );
    }
  }
  context.putImageData(result, 0, 0);
  return output.toDataURL('image/webp', 0.94);
}

function renderPreview(sheets) {
  const canvas = document.createElement('canvas');
  const cellW = 430;
  const cellH = 565;
  canvas.width = cellW * 3;
  canvas.height = cellH * 2 + 20;
  const context = canvas.getContext('2d');
  const background = context.createLinearGradient(0, 0, 0, canvas.height);
  background.addColorStop(0, '#101013');
  background.addColorStop(0.55, '#08080a');
  background.addColorStop(1, '#030304');
  context.fillStyle = background;
  context.fillRect(0, 0, canvas.width, canvas.height);

  const images = {};
  TYPES.forEach((type) => {
    const image = new Image();
    image.src = sheets[type];
    images[type] = image;
  });

  return Promise.all(
    TYPES.map(
      (type) =>
        new Promise((resolve) => {
          images[type].onload = () => resolve();
        })
    )
  ).then(() => {
    TYPES.forEach((type, index) => {
      const column = index % 3;
      const row = Math.floor(index / 3);
      const x = column * cellW;
      const y = row * cellH;
      context.drawImage(
        images[type],
        0,
        0,
        CELL_W,
        CELL_H,
        x + 5,
        y + 5,
        cellW - 10,
        (cellW - 10) * (CELL_H / CELL_W)
      );
      context.fillStyle = 'rgba(245,245,242,0.62)';
      context.font = '300 12px Inter, sans-serif';
      context.textAlign = 'center';
      context.fillText(type.toUpperCase(), x + cellW / 2, y + cellH - 14);
    });
    return canvas.toDataURL('image/png');
  });
}

window.renderAll = async () => {
  const images = {};
  for (const type of TYPES) {
    images[type] = await loadImage(`/chess%20pieces/${type}.png`);
  }
  knightFaceTexture = createKnightHeadTexture(images.knight);

  const sheets = {};
  const setStills = {};
  for (const type of TYPES) {
    sheets[type] = renderSheet(type);
    setStills[type] = setStill(images[type]);
  }
  const preview = await renderPreview(sheets);
  return {
    sheets,
    setStills,
    preview,
    frames: FRAMES,
    cellWidth: CELL_W,
    cellHeight: CELL_H,
  };
};

window.__ready = true;
