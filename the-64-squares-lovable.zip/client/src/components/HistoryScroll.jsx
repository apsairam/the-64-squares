import { useLayoutEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import ChessBoard from './ChessBoard';
import { INITIAL_PIECES } from '../data/board';
import {
  INITIAL_BY_ID,
  MOVE_LABELS,
  SCHOLARS_MATE,
} from '../data/scholarsMate';

gsap.registerPlugin(ScrollTrigger);

export default function HistoryScroll({ hero, chapters }) {
  const sectionRef = useRef(null);
  const triggerRef = useRef(null);
  const stepRef = useRef(0);
  const [step, setStep] = useState(0);

  const frames = [hero, ...chapters];
  const frameCount = frames.length;
  const isMate = step === frameCount - 1;

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return undefined;

    const board = section.querySelector('.board');
    const pieceEls = new Map(
      [...(board?.querySelectorAll('[data-piece-id]') ?? [])].map((el) => [
        el.dataset.pieceId,
        el,
      ])
    );

    pieceEls.forEach((el, id) => {
      const initial = INITIAL_BY_ID.get(id);
      if (!initial) return;
      gsap.set(el, {
        left: `${initial.file * 12.5}%`,
        top: `${initial.y * 12.5}%`,
        opacity: 1,
        zIndex: 2,
        clearProps: 'transform',
      });
    });

    const reducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    if (reducedMotion) {
      return undefined;
    }

    const timeline = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: 'top top',
        end: `+=${(frameCount - 1) * 100}%`,
        pin: true,
        anticipatePin: 1,
        scrub: 0.55,
        onUpdate: (self) => {
          const next = Math.min(
            frameCount - 1,
            Math.floor(self.progress * frameCount + 0.0001)
          );
          if (next !== stepRef.current) {
            stepRef.current = next;
            setStep(next);
          }
        },
      },
    });

    // Keep the timeline exactly as long as the number of story frames.
    const playhead = { value: 0 };
    timeline.to(
      playhead,
      { value: frameCount, duration: frameCount, ease: 'none' },
      0
    );

    SCHOLARS_MATE.forEach((move, index) => {
      const piece = pieceEls.get(move.pieceId);
      if (!piece) return;

      const at = index + 1;

      timeline.set(piece, { zIndex: 4 }, at);
      timeline.to(
        piece,
        {
          left: `${move.to.file * 12.5}%`,
          top: `${move.to.y * 12.5}%`,
          duration: 0.55,
          ease: 'power2.inOut',
        },
        at + 0.1
      );
      timeline.set(piece, { zIndex: 2 }, at + 0.65);

      if (move.captureId) {
        const captured = pieceEls.get(move.captureId);
        if (captured) {
          timeline.to(
            captured,
            {
              opacity: 0,
              scale: 0.45,
              duration: 0.22,
              ease: 'power1.in',
            },
            at + 0.42
          );
        }
      }
    });

    triggerRef.current = timeline.scrollTrigger;

    const refresh = () => ScrollTrigger.refresh();
    if (document.fonts?.ready) {
      document.fonts.ready.then(refresh);
    } else {
      window.setTimeout(refresh, 250);
    }

    return () => {
      timeline.scrollTrigger?.kill();
      timeline.kill();
      triggerRef.current = null;
    };
  }, [frameCount]);

  const jumpToFrame = (index) => {
    const trigger = triggerRef.current;
    if (!trigger) {
      if (index === 0) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        document
          .getElementById(frames[index].id)
          ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      return;
    }
    const progress = (index + 0.82) / frameCount;
    const top = trigger.start + (trigger.end - trigger.start) * progress;
    window.scrollTo({ top, behavior: 'smooth' });
  };

  return (
    <section ref={sectionRef} className="lesson" id="history">
      <div className="lesson__pin">
        <div className="lesson__board-wrap">
          <ChessBoard
            pieces={INITIAL_PIECES}
            mateSquare={isMate ? 'f7' : null}
            label={`Scholar’s Mate study — ${MOVE_LABELS[step]}`}
          />
        </div>

        <div className="lesson__scrim" aria-hidden="true" />

        <div className="lesson__overlay">
          <div className="lesson__frames">
            {frames.map((item, index) => (
              <article
                key={item.title}
                className={`lesson__frame ${
                  step === index ? 'is-active' : ''
                }`}
                aria-hidden={step !== index}
              >
                <span className="lesson__kicker">{item.kicker}</span>
                <p className="lesson__headline">{item.title}</p>
                {item.subtitle && (
                  <p className="lesson__subtitle">{item.subtitle}</p>
                )}
                <p className="lesson__desc">{item.lede}</p>
                {item.meta && (
                  <ul className="lesson__meta">
                    {item.meta.map((entry) => (
                      <li key={entry}>{entry}</li>
                    ))}
                  </ul>
                )}
                {item.hint && (
                  <div className="lesson__hint" aria-hidden="true">
                    <span>Scroll to read</span>
                    <span className="lesson__hint-line" />
                  </div>
                )}
              </article>
            ))}
          </div>

          <div className="lesson__progress" aria-label="Chapter progress">
            <div className="lesson__readout">
              <span className="lesson__study">Scholar’s Mate</span>
              <span className="lesson__move" aria-live="polite">
                {MOVE_LABELS[step]}
              </span>
            </div>

            <div className="lesson__nav">
              <span className="lesson__count">
                {String(step + 1).padStart(2, '0')} /{' '}
                {String(frameCount).padStart(2, '0')}
              </span>
              <div className="lesson__ticks">
                {frames.map((item, index) => (
                  <button
                    key={item.title}
                    type="button"
                    className={`tick ${index <= step ? 'is-done' : ''}`}
                    onClick={() => jumpToFrame(index)}
                    aria-label={`Go to ${item.title} — ${
                      MOVE_LABELS[index]
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
