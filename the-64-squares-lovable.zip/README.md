# The 64 Squares — The Art, History & Geometry of Chess

A full-stack chess history landing page. It opens on a full-screen black-and-white
board; scrolling pins the board and reveals a seven-chapter history of chess, from
Gupta-era chaturanga to the Immortal Game of 1851 and the modern game. The board
itself plays Scholar’s Mate while you read, one ply per chapter — from `1. e4` to
`4. Qxf7#` — with the final mating square marked on f7. The opening screen is
deliberately just the board and its typography. Below it, a solid 3D chess piece
turns in place on the right of every article, and the anatomy portraits and
movement diagrams drift with the scroll.

Below the pinned story, the full articles expand on the same chapters: the
origins of chess, the Immortal Game with its key moments and PGN, the three old
laws, the anatomy of every piece, the three phases of play, and a closing note on
the game's unbroken lineage.

## Stack

- **Frontend:** React 18 + Vite
- **Scroll pinning & scrubbing:** GSAP + ScrollTrigger (the board is pinned; the
  Scholar’s Mate timeline is scrubbed by the scroll position)
- **3D pieces:** six gunmetal pieces rebuilt from the supplied renders as
  72-frame turntable WebP sheets with Three.js at build time, replayed on a
  lightweight 2D canvas at runtime; the exact supplied renders are used for the
  anatomy portraits and phone fallbacks
- **Backend:** Node.js + Express
- **Content API:** `GET /api/content` (the client falls back to local content if
  the API is offline)

No database is needed because the site has no accounts, payments or saved state.

## Run it locally

From the project root:

```bash
npm install
npm --prefix client install
npm --prefix server install
npm run dev
```

Open `http://localhost:5173`. The API runs on `http://localhost:4000` and Vite
proxies `/api` requests to it.

## Production build

```bash
npm run build
npm start
```

Open `http://localhost:4000`. Express serves the built React app and the API from
the same server.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Runs the Express API and the Vite dev server together |
| `npm run dev:client` | Runs only the React app (port 5173) |
| `npm run dev:server` | Runs only the API (port 4000) |
| `npm run build` | Builds the React app into `client/dist` |
| `npm run build:pieces` | Re-renders the six 3D turntable sheets, the supplied-set stills and the piece preview |
| `npm start` | Serves the production build and API on port 4000 |
| `node scripts/check.mjs` | Playwright check for console errors, API status, all story frames, the mate state, 3D piece spin, parallax and reduced motion |
| `node scripts/shoot.mjs` | Writes 1920×1080, desktop and mobile previews to `shots/` |

The Playwright scripts expect the production server to be running on port 4000.
`node scripts/shoot.mjs` also writes clean 1920×1080 board renders:
`shots/board-1920x1080-start.png` and `shots/board-1920x1080-mate.png`.

## Project layout

```
client/
  src/
    components/
      ChessBoard.jsx      # stretched 8×8 board, 32 pieces and the mate marker
      HistoryScroll.jsx   # pin + Scholar’s Mate scrub + chapter crossfade
      Piece3D.jsx         # lazy canvas turntable for a 3D piece sheet
      BoardDiagram.jsx    # small static boards used in the piece guide
      PieceGuide.jsx      # six piece cards with parallax portraits and diagrams
      Reveal.jsx          # fade-up section reveal
    assets/pieces/        # generated 72-frame sheets and set-*.webp stills
    data/
      board.js            # files, glyphs and the 32 starting pieces
      scholarsMate.js     # the seven plies, labels and initial-piece lookup
      chessContent.js     # all copy (also served by the API)
    App.jsx
    styles.css
server/
  index.js                # Express API + static production server
scripts/
  build-pieces.mjs        # renders the 3D piece sheets and preview
  pieces/gen.html         # headless Three.js turntable stage
  pieces/gen.js           # piece models, chrome lighting and frame export
  pieces/extract-set.py   # traces the supplied renders into 3D profiles
  pieces/set-profiles.js  # generated lathe and knight outlines
  check.mjs               # Playwright smoke test
  shoot.mjs               # Playwright screenshots
```

## How the scroll story works

The hero section is pinned with ScrollTrigger for `700%` of the viewport height.
Eight frames — the hero plus seven chapters — crossfade over the board as you
scroll. Each chapter advances one ply of Scholar’s Mate:

```
1. e4      e5
2. Bc4     Nc6
3. Qh5     Nf6??
4. Qxf7#
```

The movement is scrubbed directly by the scrollbar: scrolling up rewinds the
moves, the captured f7 pawn reappears, and the checkmate marker clears. The
notation in the bottom-left readout tracks the current ply, and the f7 mating
square pulses when the final position is reached.

1. The 64 Squares (hero)
2. I. Chaturanga & Origins (6th C.) — 1. e4
3. II. Shatranj & the Journey West — 1... e5
4. III. The Immortal Game (1851) — 2. Bc4
5. IV. The Old Laws — 2... Nc6
6. V. The Anatomy of Every Piece — 3. Qh5
7. VI. The Three Phases of Play — 3... Nf6
8. VII. The Unbroken Dialogue — 4. Qxf7#

The eight tick marks at the bottom left are buttons: clicking one scrolls to the
end-of-frame hold, so the move for that chapter has landed. Scrolling up rewinds
the story. `prefers-reduced-motion` users skip the pin, the move animation, the
turntable spin and the parallax drift, and get the hero plus the full written
history below; in that mode the ticks jump to the matching article section and
each 3D piece holds a single three-quarter frame.

## Content notes

The copy is adapted from the supplied Google Stitch export (`code.html`): the
hero introduction, the three laws, the Immortal Game annotations, the piece
anatomy and the three phases. It is reorganized into a history-first narrative,
with the Stitch material expanded into the scroll chapters and the full articles
below. The original export files (`code.html`, `DESIGN.md`, `screen.png`) are left
untouched.

## Design notes

- Board: `#f2f2f2` and `#101010`
- White pieces: light grey with a dark edge
- Black pieces: graphite with a light rim
- Type: Inter (100–300 weights) and JetBrains Mono for labels and PGN
- The board fills the viewport (`100% × 100svh`), so on a 1920×1080 screen it
  fills the 16:9 frame exactly. The squares stretch with the viewport, while the
  glyphs are sized from the smaller cell dimension (`min(8.2cqw, 8.2cqh)`) so the
  pieces stay legible.
- The opening screen has no decorative piece: the stretched board and the thin
  white type carry it alone.
- Each article has a solid gunmetal 3D piece on the right — pawn, knight, queen,
  rook, bishop, king, pawn — that turns around its own vertical axis in place.
  Section pieces do not drift vertically.
- The piece surfaces use the supplied set's dark-chrome gradient with broad
  studio reflections and polished silver bands.
- In the anatomy chapter, each supplied-set portrait and its movement diagram
  use scroll-linked vertical parallax in opposite directions, so the card reads
  as layered. Matching motion is disabled under `prefers-reduced-motion`.
- Phones use the still portrait for the section sculptures so they do not decode
  the full turntable sheets; the in-place spin runs on larger screens.
- No header, no nav and no footer on the hero — the board is the page.

## 3D piece pipeline

The six pieces are rebuilt from the supplied gunmetal set. `extract-set.py`
reads the alpha silhouettes in `chess pieces/`, traces the five turned pieces
into normalised lathe profiles, and traces the knight as a closed outline.
`gen.js` turns those profiles into bevelled 3D geometry: lathe bodies, layered
base and collar rings, a crenellated rook, a scalloped queen crown, a cross
finial, and a lofted knight whose dimensional head carries the supplied
profile as a crisp side facing, with modelled eyes and nostrils. A custom
studio environment supplies the broad chrome reflections; each piece makes one
revolution across 72 frames.

`npm run build:pieces` starts a temporary static server, renders the six pieces
in headless Chrome through Three.js, writes the 6×12 sprite sheets and the
trimmed `set-*.webp` stills to `client/src/assets/pieces/`, and saves a contact
sheet to `shots/pieces-preview.png`. The stills are de-fringed against the
original white background so the dark chrome sits cleanly on the near-black
page. The generated assets total roughly 5 MB, mostly the section sheets.
Three.js is a development dependency and never ships in the client bundle.

At runtime, `Piece3D.jsx` lazy-creates a sheet only when the piece comes within
420px of the viewport, draws one 420×525 cell at a time to a
device-pixel-ratio-aware canvas, and pauses the ticker when the piece leaves
that range. A single shared `requestAnimationFrame` loop drives all visible
pieces. The anatomy portraits use `PieceStill` with the exact supplied renders,
so the six small cards share no full turntable sheets in memory; only the
section sculptures decode them.

## Deploying

Any host that can run Node works:

1. `npm run build`
2. `npm start` with `PORT` set by the host
3. Point the domain at the Node service

You can also deploy `client/dist` to a static host, but then the `/api/content`
endpoint needs to be hosted separately and the fetch URL updated.
