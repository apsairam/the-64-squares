import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chessContent } from '../client/src/data/chessContent.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT) || 4000;

app.use(express.json());

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'the-64-squares-api', uptime: process.uptime() });
});

app.get('/api/content', (_req, res) => {
  res.json(chessContent);
});

app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

const distDir = path.resolve(__dirname, '../client/dist');
const indexFile = path.join(distDir, 'index.html');

app.use(express.static(distDir));

app.get('*', (_req, res) => {
  if (!fs.existsSync(indexFile)) {
    res
      .status(503)
      .send('Client build not found. Run "npm run build" from the project root.');
    return;
  }
  res.sendFile(indexFile);
});

app.listen(port, () => {
  console.log(`The 64 Squares API + site running at http://localhost:${port}`);
});
