import { useEffect, useRef, useState } from 'react';
import pawnSheet from '../assets/pieces/pawn.webp';
import knightSheet from '../assets/pieces/knight.webp';
import bishopSheet from '../assets/pieces/bishop.webp';
import rookSheet from '../assets/pieces/rook.webp';
import queenSheet from '../assets/pieces/queen.webp';
import kingSheet from '../assets/pieces/king.webp';
import pawnStill from '../assets/pieces/set-pawn.webp';
import knightStill from '../assets/pieces/set-knight.webp';
import bishopStill from '../assets/pieces/set-bishop.webp';
import rookStill from '../assets/pieces/set-rook.webp';
import queenStill from '../assets/pieces/set-queen.webp';
import kingStill from '../assets/pieces/set-king.webp';

const SHEETS = {
  pawn: pawnSheet,
  knight: knightSheet,
  bishop: bishopSheet,
  rook: rookSheet,
  queen: queenSheet,
  king: kingSheet,
};

const STILLS = {
  pawn: pawnStill,
  knight: knightStill,
  bishop: bishopStill,
  rook: rookStill,
  queen: queenStill,
  king: kingStill,
};

const FRAMES = 72;
const COLS = 6;
const CELL_W = 420;
const CELL_H = 525;
const FRAME_MS = 110;

const sheetCache = new Map();
const tickers = new Set();
let rafId = 0;

function tick(now) {
  tickers.forEach((ticker) => ticker(now));
  rafId = tickers.size ? window.requestAnimationFrame(tick) : 0;
}

function subscribe(ticker) {
  tickers.add(ticker);
  if (!rafId) rafId = window.requestAnimationFrame(tick);
  return () => {
    tickers.delete(ticker);
    if (!tickers.size && rafId) {
      window.cancelAnimationFrame(rafId);
      rafId = 0;
    }
  };
}

function sheetFor(piece) {
  if (sheetCache.has(piece)) return sheetCache.get(piece);

  const entry = {
    image: new Image(),
    ready: false,
    failed: false,
    waiters: new Set(),
  };
  entry.image.decoding = 'async';
  entry.image.onload = () => {
    entry.ready = true;
    entry.waiters.forEach((waiter) => waiter());
    entry.waiters.clear();
  };
  entry.image.onerror = () => {
    entry.failed = true;
    entry.waiters.clear();
  };
  entry.image.src = SHEETS[piece] ?? SHEETS.queen;
  sheetCache.set(piece, entry);
  return entry;
}

function whenSheetReady(piece, callback) {
  const entry = sheetFor(piece);
  if (entry.ready) {
    callback();
    return () => {};
  }
  if (entry.failed) return () => {};

  let active = true;
  const waiter = () => {
    if (active) callback();
  };
  entry.waiters.add(waiter);
  return () => {
    active = false;
    entry.waiters.delete(waiter);
  };
}

export function PieceStill({ piece = 'queen', className = '' }) {
  return (
    <span className={`piece3d piece3d--still ${className}`.trim()}>
      <img
        src={STILLS[piece] ?? STILLS.queen}
        alt=""
        loading="lazy"
        decoding="async"
      />
    </span>
  );
}

export default function Piece3D({
  piece = 'queen',
  className = '',
  phase = 0,
}) {
  const frameRef = useRef(null);
  const canvasRef = useRef(null);
  const [smallViewport, setSmallViewport] = useState(
    () => window.matchMedia('(max-width: 680px)').matches
  );

  useEffect(() => {
    const query = window.matchMedia('(max-width: 680px)');
    const onChange = () => setSmallViewport(query.matches);
    query.addEventListener('change', onChange);
    return () => query.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    const frame = frameRef.current;
    const canvas = canvasRef.current;
    const context = canvas?.getContext('2d');
    if (!frame || !canvas || !context) return undefined;

    const reducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;
    let entry = null;
    let readyCleanup = null;
    const baseFrame = ((phase % FRAMES) + FRAMES) % FRAMES;

    let currentFrame = -1;
    let visible = false;
    let unsubscribe = null;
    let start = 0;

    const draw = (rawFrame, force = false) => {
      if (!entry?.ready || entry.failed) return;
      const frameIndex = ((rawFrame % FRAMES) + FRAMES) % FRAMES;
      if (frameIndex === currentFrame && !force) return;

      const bounds = canvas.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return;

      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.round(bounds.width * ratio);
      const height = Math.round(bounds.height * ratio);

      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      const column = frameIndex % COLS;
      const row = Math.floor(frameIndex / COLS);
      context.clearRect(0, 0, width, height);
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = 'high';
      context.drawImage(
        entry.image,
        column * CELL_W,
        row * CELL_H,
        CELL_W,
        CELL_H,
        0,
        0,
        width,
        height
      );

      currentFrame = frameIndex;
      canvas.dataset.frame = String(frameIndex);
      canvas.dataset.ready = 'true';
      frame.classList.add('is-ready');
    };

    const startTicker = () => {
      if (unsubscribe || reducedMotion || !entry?.ready) return;
      start = window.performance.now();
      unsubscribe = subscribe((now) => {
        const elapsed = Math.max(0, now - start);
        const frame =
          (Math.floor(elapsed / FRAME_MS) + baseFrame) % FRAMES;
        draw(frame);
      });
    };

    const stopTicker = () => {
      if (unsubscribe) {
        unsubscribe();
        unsubscribe = null;
      }
    };

    const ensureReady = () => {
      if (!entry) entry = sheetFor(piece);
      if (readyCleanup) return;
      readyCleanup = whenSheetReady(piece, () => {
        draw(reducedMotion ? 0 : baseFrame, true);
        if (visible) startTicker();
      });
    };

    const resizeObserver = new ResizeObserver(() => {
      draw(reducedMotion ? 0 : Math.max(currentFrame, 0), true);
    });
    resizeObserver.observe(frame);

    let scrollFrame = 0;
    const nearViewport = () => {
      const bounds = frame.getBoundingClientRect();
      return bounds.bottom > -420 && bounds.top < window.innerHeight + 420;
    };
    const syncVisibility = () => {
      scrollFrame = 0;
      const near = nearViewport();
      if (near) {
        const wasVisible = visible;
        visible = true;
        ensureReady();
        if (entry?.ready) {
          if (!wasVisible) {
            draw(reducedMotion ? 0 : Math.max(currentFrame, baseFrame), true);
          }
          startTicker();
        }
      } else if (visible) {
        visible = false;
        stopTicker();
      }
    };
    const onScroll = () => {
      if (!scrollFrame) {
        scrollFrame = window.requestAnimationFrame(syncVisibility);
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    const initialSync = window.requestAnimationFrame(syncVisibility);

    return () => {
      if (readyCleanup) readyCleanup();
      stopTicker();
      resizeObserver.disconnect();
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (scrollFrame) window.cancelAnimationFrame(scrollFrame);
      if (initialSync) window.cancelAnimationFrame(initialSync);
    };
  }, [piece, phase, smallViewport]);

  if (smallViewport) {
    return <PieceStill piece={piece} className={className} />;
  }

  return (
    <span ref={frameRef} className={`piece3d ${className}`.trim()}>
      <canvas
        ref={canvasRef}
        data-piece3d="true"
        data-piece={piece}
        aria-hidden="true"
      />
    </span>
  );
}
