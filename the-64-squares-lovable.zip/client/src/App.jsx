import { useEffect, useState } from 'react';
import HistoryScroll from './components/HistoryScroll';
import Piece3D from './components/Piece3D';
import PieceGuide from './components/PieceGuide';
import Reveal from './components/Reveal';
import { chessContent as localContent } from './data/chessContent';

function SectionHead({ kicker, title, body }) {
  return (
    <div className="section-head">
      <p className="kicker">{kicker}</p>
      <h2 className="display">{title}</h2>
      {body && <p className="lede">{body}</p>}
    </div>
  );
}

function Facts({ facts }) {
  return (
    <dl className="stat-row chapter__stats">
      {facts.map((fact) => (
        <div className="stat" key={fact.label}>
          <dt>{fact.label}</dt>
          <dd>{fact.value}</dd>
        </div>
      ))}
    </dl>
  );
}

function LawsGrid({ laws }) {
  return (
    <div className="three-grid">
      {laws.map((law, index) => (
        <article className="rule-card" key={law.title}>
          <span className="rule-card__index">
            {String(index + 1).padStart(2, '0')}
          </span>
          <h3 className="rule-card__title">{law.title}</h3>
          <p className="rule-card__notation">{law.tag}</p>
          <p className="rule-card__text">{law.text}</p>
        </article>
      ))}
    </div>
  );
}

function PhasesGrid({ phases }) {
  return (
    <div className="three-grid phases">
      {phases.map((phase, index) => (
        <article className="phase-card" key={phase.phase}>
          <span className="phase-card__index">
            {String(index + 1).padStart(2, '0')}.
          </span>
          <h3 className="phase-card__title">{phase.phase}</h3>
          <p className="phase-card__text">{phase.text}</p>
        </article>
      ))}
    </div>
  );
}

function ImmortalExtras({ immortal }) {
  const [copied, setCopied] = useState(false);

  const copyPgn = async () => {
    try {
      await navigator.clipboard.writeText(immortal.pgn);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <>
      <div className="moment-list">
        {immortal.moments.map((moment, index) => (
          <article className="moment" key={moment.move}>
            <span className="moment__index">
              {String(index + 1).padStart(2, '0')}
            </span>
            <code className="moment__move">{moment.move}</code>
            <div className="moment__content">
              <h3 className="moment__title">{moment.title}</h3>
              <p className="moment__text">{moment.text}</p>
            </div>
          </article>
        ))}
      </div>

      <blockquote className="quote quote--wide">{immortal.quote}</blockquote>
      <p className="legacy-note">{immortal.legacy}</p>

      <div className="pgn">
        <div className="pgn__head">
          <span>Portable Game Notation · London 1851</span>
          <button type="button" onClick={copyPgn}>
            {copied ? 'Copied' : 'Copy PGN'}
          </button>
        </div>
        <pre>{immortal.pgn}</pre>
      </div>
    </>
  );
}

function Chapter({ chapter, content, index }) {
  return (
    <section className="section" id={chapter.id}>
      <Piece3D piece={chapter.piece} className="chapter__piece" phase={index * 4} />

      <Reveal className="section__inner">
        <SectionHead
          kicker={chapter.kicker}
          title={chapter.title}
          body={chapter.lede}
        />

        <div className="chapter__body">
          {chapter.body.map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}
        </div>

        {chapter.facts && <Facts facts={chapter.facts} />}

        {chapter.quote && (
          <blockquote className="quote">{chapter.quote.text}</blockquote>
        )}

        {chapter.id === 'immortal' && (
          <ImmortalExtras immortal={content.immortal} />
        )}

        {chapter.id === 'laws' && <LawsGrid laws={content.laws} />}

        {chapter.id === 'pieces' && <PieceGuide pieces={content.pieces} />}

        {chapter.id === 'phases' && <PhasesGrid phases={content.phases} />}

        {chapter.id === 'legacy' && (
          <a className="button" href="#history">
            Read the story again
          </a>
        )}
      </Reveal>
    </section>
  );
}

export default function App() {
  const [content, setContent] = useState(localContent);
  const [apiStatus, setApiStatus] = useState('local');

  useEffect(() => {
    let cancelled = false;

    fetch('/api/content')
      .then((response) => {
        if (!response.ok) throw new Error('API unavailable');
        return response.json();
      })
      .then((data) => {
        if (!cancelled) {
          setContent(data);
          setApiStatus('live');
        }
      })
      .catch(() => {
        if (!cancelled) setApiStatus('local');
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <main>
      <h1 className="sr-only">
        The 64 Squares — the art, history and geometry of chess
      </h1>

      <HistoryScroll hero={content.hero} chapters={content.chapters} />

      <div className="content">
        {content.chapters.map((chapter, index) => (
          <Chapter
            key={chapter.id}
            chapter={chapter}
            content={content}
            index={index}
          />
        ))}

        <footer className="footer">
          <div className="footer__inner">
            <div className="footer__brand">
              <span className="footer__name">{content.brand.name}</span>
              <span className="footer__tagline">{content.brand.tagline}</span>
            </div>
            <nav className="footer__nav" aria-label="Footer">
              <a href="#chaturanga">Origins</a>
              <a href="#immortal">Immortal Game</a>
              <a href="#pieces">Anatomy</a>
              <a href="#phases">Masterclass</a>
            </nav>
            <div className="footer__meta">
              <span>© 2026 · Archive Nº 64</span>
              <span className={`footer__api ${apiStatus}`}>
                <span className="footer__dot" aria-hidden="true" />
                {apiStatus === 'live' ? 'Node API connected' : 'Local content'}
              </span>
            </div>
          </div>
        </footer>
      </div>
    </main>
  );
}
