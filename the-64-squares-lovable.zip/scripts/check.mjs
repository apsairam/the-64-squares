import { chromium } from 'playwright';

const browser = await chromium.launch({ channel: 'chrome', headless: true });
const page = await browser.newPage({
  viewport: { width: 1440, height: 1000 },
});

const errors = [];
page.on('console', (message) => {
  if (message.type() === 'error') errors.push(`console: ${message.text()}`);
});
page.on('pageerror', (error) => errors.push(`page: ${error.message}`));

await page.goto('http://localhost:4000/', { waitUntil: 'networkidle' });
await page.waitForTimeout(1400);

const apiStatus = await page.locator('.footer__api').innerText();
const tickCount = await page.locator('.tick').count();
const openingGhostCount = await page
  .locator('.lesson__sigil, .lesson .piece3d')
  .count();
const steps = [];

for (let index = 0; index < tickCount; index += 1) {
  await page.locator('.tick').nth(index).click();
  await page.waitForTimeout(1100);
  steps.push({
    index,
    count: await page.locator('.lesson__count').innerText(),
    move: await page.locator('.lesson__move').innerText(),
    active: await page
      .locator('.lesson__frame.is-active .lesson__headline')
      .innerText(),
  });
}

const readBoard = () =>
  page.evaluate(() => {
    const board = document.querySelector('.lesson .board');
    const queen = document.querySelector('[data-piece-id="w-q-d1"]');
    const capturedPawn = document.querySelector('[data-piece-id="b-p-f7"]');
    const boardRect = board.getBoundingClientRect();
    const queenRect = queen.getBoundingClientRect();
    const cellWidth = boardRect.width / 8;
    const cellHeight = boardRect.height / 8;

    return {
      width: Math.round(boardRect.width),
      height: Math.round(boardRect.height),
      queenFile: Math.round((queenRect.left - boardRect.left) / cellWidth),
      queenY: Math.round((queenRect.top - boardRect.top) / cellHeight),
      pawnOpacity: Number(
        window.getComputedStyle(capturedPawn).opacity
      ),
      mateSquare:
        document.querySelector('.lesson .square.is-mate')?.dataset.square ??
        null,
    };
  });

const finalBoard = await readBoard();

await page.evaluate(() =>
  window.scrollTo({ top: 0, behavior: 'instant' })
);
await page.waitForTimeout(1500);
const resetBoard = await readBoard();

const sectionTop = (id) =>
  page.evaluate(
    (sectionId) =>
      document.querySelector(`#${sectionId}`).getBoundingClientRect().top +
      window.scrollY,
    id
  );

const waitForPiece = async (selector) => {
  await page.waitForFunction(
    (target) => {
      const canvas = document.querySelector(target);
      return canvas?.dataset.ready === 'true';
    },
    selector,
    { timeout: 8000 }
  );
};

const chaturangaTop = await sectionTop('chaturanga');
await page.evaluate(
  (y) => window.scrollTo({ top: y, behavior: 'instant' }),
  chaturangaTop
);
await waitForPiece('#chaturanga .chapter__piece canvas');
const chapterFrameBefore = await page
  .locator('#chaturanga .chapter__piece canvas')
  .getAttribute('data-frame');
const chapterPieceBoxBefore = await page
  .locator('#chaturanga .chapter__piece')
  .boundingBox();
await page.waitForTimeout(1600);
const chapterFrameAfter = await page
  .locator('#chaturanga .chapter__piece canvas')
  .getAttribute('data-frame');
const chapterPieceBoxAfter = await page
  .locator('#chaturanga .chapter__piece')
  .boundingBox();

const chapterPieceCount = await page.locator('.chapter__piece').count();
const chapterPieceTypes = await page
  .locator('.chapter__piece canvas')
  .evaluateAll((nodes) => nodes.map((node) => node.dataset.piece));

const piecesTop = await sectionTop('pieces');
await page.evaluate(
  (y) => window.scrollTo({ top: y, behavior: 'instant' }),
  piecesTop
);
await page.waitForTimeout(700);
await page.locator('.piece-grid').scrollIntoViewIfNeeded();
await page.waitForFunction(
  () => {
    const images = [
      ...document.querySelectorAll('#pieces .piece-card__piece img'),
    ];
    return (
      images.length === 6 &&
      images.every((image) => image.complete && image.naturalWidth > 0)
    );
  },
  null,
  { timeout: 8000 }
);
await page.waitForTimeout(1100);

const anatomyPieceCount = await page
  .locator('#pieces .piece-card__piece img')
  .count();
const anatomyReadyCount = await page
  .locator('#pieces .piece-card__piece img')
  .evaluateAll(
    (images) =>
      images.filter((image) => image.complete && image.naturalWidth > 0).length
  );
const anatomySources = await page
  .locator('#pieces .piece-card__piece img')
  .evaluateAll((images) =>
    images.map((image) => new URL(image.currentSrc || image.src).pathname)
  );

const parallaxBefore = await page
  .locator('#pieces .piece-card__media .diagram__board')
  .first()
  .evaluate((el) => el.style.transform);
const portraitBefore = await page
  .locator('#pieces .piece-card__piece')
  .first()
  .evaluate((el) => el.style.transform);
await page.evaluate(() =>
  window.scrollBy({ top: 340, behavior: 'instant' })
);
await page.waitForTimeout(700);
const parallaxAfter = await page
  .locator('#pieces .piece-card__media .diagram__board')
  .first()
  .evaluate((el) => el.style.transform);
const portraitAfter = await page
  .locator('#pieces .piece-card__piece')
  .first()
  .evaluate((el) => el.style.transform);

const sections = await page
  .locator('.content section.section')
  .evaluateAll((nodes) => nodes.map((node) => node.id));

const widePage = await browser.newPage({
  viewport: { width: 1920, height: 1080 },
});
await widePage.goto('http://localhost:4000/', { waitUntil: 'networkidle' });
await widePage.waitForTimeout(1000);
const wideBoard = await widePage.evaluate(() => {
  const rect = document.querySelector('.lesson .board').getBoundingClientRect();
  return { width: Math.round(rect.width), height: Math.round(rect.height) };
});
await widePage.close();

const reducedPage = await browser.newPage({
  viewport: { width: 1440, height: 1000 },
  reducedMotion: 'reduce',
});
const reducedErrors = [];
reducedPage.on('console', (message) => {
  if (message.type() === 'error') {
    reducedErrors.push(`console: ${message.text()}`);
  }
});
reducedPage.on('pageerror', (error) =>
  reducedErrors.push(`page: ${error.message}`)
);
await reducedPage.goto('http://localhost:4000/', {
  waitUntil: 'networkidle',
});
await reducedPage.waitForTimeout(1200);
const reducedTickCount = await reducedPage.locator('.tick').count();
const reducedPinCount = await reducedPage.locator('.pin-spacer').count();
const reducedTop = await reducedPage.evaluate(
  () =>
    document.querySelector('#chaturanga').getBoundingClientRect().top +
    window.scrollY
);
await reducedPage.evaluate(
  (y) => window.scrollTo({ top: y, behavior: 'instant' }),
  reducedTop
);
await reducedPage.waitForFunction(
  () =>
    document.querySelector('#chaturanga .chapter__piece canvas')?.dataset
      .ready === 'true',
  null,
  { timeout: 8000 }
);
const reducedFrameBefore = await reducedPage
  .locator('#chaturanga .chapter__piece canvas')
  .getAttribute('data-frame');
await reducedPage.waitForTimeout(900);
const reducedFrameAfter = await reducedPage
  .locator('#chaturanga .chapter__piece canvas')
  .getAttribute('data-frame');
const reducedPortraitTransform = await reducedPage
  .locator('#pieces .piece-card__piece')
  .first()
  .evaluate((el) => el.style.transform);
const reducedBoardTransform = await reducedPage
  .locator('#pieces .piece-card__media .diagram__board')
  .first()
  .evaluate((el) => el.style.transform);
await reducedPage.close();

const translateY = (value) => {
  const match = /translate3d\(0px, (-?[\d.]+)px/.exec(value ?? '');
  return match ? Number(match[1]) : NaN;
};
const portraitShift = Math.abs(
  translateY(portraitAfter) - translateY(portraitBefore)
);
const boardShift = Math.abs(translateY(parallaxAfter) - translateY(parallaxBefore));
const chapterPieceStaysPut =
  Boolean(chapterPieceBoxBefore) &&
  Boolean(chapterPieceBoxAfter) &&
  Math.abs(chapterPieceBoxBefore.x - chapterPieceBoxAfter.x) < 1 &&
  Math.abs(chapterPieceBoxBefore.y - chapterPieceBoxAfter.y) < 1;

const checks = {
  apiConnected: apiStatus.toLowerCase().includes('connected'),
  eightFrames: tickCount === 8 && steps.length === 8,
  movesAdvance: steps.map((step) => step.move).join(' | ').includes(
    '4. Qxf7#'
  ),
  finalQueenOnF7:
    finalBoard.queenFile === 5 && finalBoard.queenY === 1,
  pawnCaptured: finalBoard.pawnOpacity < 0.1,
  checkmateMarked: finalBoard.mateSquare === 'f7',
  resetQueenOnD1:
    resetBoard.queenFile === 3 && resetBoard.queenY === 7,
  pawnRestored: resetBoard.pawnOpacity > 0.9,
  openingHasNoGhosts: openingGhostCount === 0,
  sevenChapterPieces: chapterPieceCount === 7,
  distinctChapterPieces:
    new Set(chapterPieceTypes).size >= 6,
  chapterPiecesSpin:
    Boolean(chapterFrameBefore) &&
    Boolean(chapterFrameAfter) &&
    chapterFrameBefore !== chapterFrameAfter &&
    chapterPieceStaysPut,
  sixAnatomyPieces:
    anatomyPieceCount === 6 && anatomyReadyCount === 6,
  showcaseUsesProvidedSet:
    anatomySources.length === 6 &&
    anatomySources.every((source) => source.includes('set-')),
  anatomyPieceParallax:
    Boolean(portraitBefore) &&
    Boolean(portraitAfter) &&
    portraitBefore !== portraitAfter &&
    portraitShift >= 18,
  movementBoardParallax:
    Boolean(parallaxBefore) &&
    Boolean(parallaxAfter) &&
    parallaxBefore !== parallaxAfter &&
    boardShift >= 10,
  wideBoardFills16x9:
    wideBoard.width === 1920 && wideBoard.height === 1080,
  reducedMotionSafe:
    reducedErrors.length === 0 &&
    reducedTickCount === 8 &&
    reducedPinCount === 0 &&
    reducedFrameBefore === reducedFrameAfter &&
    !reducedPortraitTransform &&
    !reducedBoardTransform,
  noErrors: errors.length === 0,
};

console.log(
  JSON.stringify(
    {
      errors,
      apiStatus,
      tickCount,
      sections,
      steps,
      finalBoard,
      resetBoard,
      openingGhostCount,
      chapterPieces: {
        count: chapterPieceCount,
        types: chapterPieceTypes,
        frameBefore: chapterFrameBefore,
        frameAfter: chapterFrameAfter,
        boxBefore: chapterPieceBoxBefore,
        boxAfter: chapterPieceBoxAfter,
      },
      anatomy: {
        count: anatomyPieceCount,
        ready: anatomyReadyCount,
        sources: anatomySources,
        portraitTransform: { before: portraitBefore, after: portraitAfter },
        boardTransform: { before: parallaxBefore, after: parallaxAfter },
        portraitShift,
        boardShift,
      },
      wideBoard,
      reducedMotion: {
        errors: reducedErrors,
        tickCount: reducedTickCount,
        pinCount: reducedPinCount,
        frameBefore: reducedFrameBefore,
        frameAfter: reducedFrameAfter,
        portraitTransform: reducedPortraitTransform,
        boardTransform: reducedBoardTransform,
      },
      checks,
      allPassed: Object.values(checks).every(Boolean),
    },
    null,
    2
  )
);
await browser.close();
