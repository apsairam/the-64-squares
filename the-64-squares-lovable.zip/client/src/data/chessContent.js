export const chessContent = {
  brand: {
    name: 'The 64 Squares',
    archive: 'Archive Nº 64',
    tagline: 'An interactive treatise on grandmaster strategy, history and algebraic precision.',
  },
  hero: {
    kicker: 'Archive Nº 64',
    title: 'The 64 Squares',
    subtitle: 'The Art, History & Geometry of Chess',
    lede: 'From 6th-century Gupta Empire Chaturanga to Persian Shatranj, through the fiery romantic gambits of Victorian cafés, down to contemporary neural networks: chess is civilization’s oldest unbroken dialogue of geometry, sacrifice, and willpower.',
    meta: ['FEN: Classical', '64 squares · 32 combatants', 'London 1851'],
    hint: true,
  },
  chapters: [
    {
      id: 'chaturanga',
      piece: 'pawn',
      kicker: 'I — Chaturanga & Origins (6th C.)',
      title: 'Born in the Gupta Empire.',
      lede: 'Sixth-century India arrays four divisions of an army on an eight-by-eight grid — and invents the game that never died.',
      body: [
        'Chess begins in 6th-century India, in the Gupta Empire, as chaturanga: “four divisions” of infantry, cavalry, elephants and chariotry. Two armies of thirty-two pieces meet on an eight-by-eight board — the same geometry the game still uses today.',
        'The dice of older board games fall away. What remains is calculation, and the first record of a dialogue that would outlive every empire that played it.',
      ],
      facts: [
        { label: 'First played', value: 'India, 6th century' },
        { label: 'Chaturanga', value: 'Four divisions' },
        { label: 'The grid', value: 'Eight by eight' },
      ],
    },
    {
      id: 'shatranj',
      piece: 'knight',
      kicker: 'II — Shatranj & the Journey West',
      title: 'Persia gave it a new name.',
      lede: 'Along the Silk Road, chaturanga becomes shatranj. Poets praise it, caliphs play it, and Europe rewrites it.',
      body: [
        'By the 7th century the game had traveled to Persia as shatranj, where poets praised it, caliphs played it, and the first great players composed problems and wrote down their games. From the Islamic world it crossed into Spain and Italy.',
        'Europe rewrote it. By the 15th century the queen and bishop had gained their modern powers, and the slow, patient game of shatranj became the violent, beautiful game we know: the Queen’s Gambit, the Italian Game, the King’s Gambit — openings named for the romance of the era.',
      ],
      facts: [
        { label: 'Persia', value: '7th century' },
        { label: 'Europe', value: '10th–15th century' },
        { label: 'The modern queen', value: 'c. 1475' },
      ],
      quote: {
        text: 'The game traveled with merchants, monks and armies — and every language gave it a new name.',
      },
    },
    {
      id: 'immortal',
      piece: 'queen',
      kicker: 'III — The Immortal Game (1851)',
      title: 'Anderssen vs Kieseritzky.',
      lede: 'London, 21 June 1851. A King’s Gambit played in a café becomes the most famous game ever lost.',
      body: [
        'In a café off the Strand, during the first international chess tournament, Adolf Anderssen sat down with Lionel Kieseritzky and played the King’s Gambit.',
        'Anderssen flung pawns and pieces forward, gave away both rooks, offered his queen at point-blank range, and mated with a bishop and two knights. When the final move landed, the room rose in applause and the table was showered with gold coins. The game has been called Immortal ever since.',
      ],
    },
    {
      id: 'laws',
      piece: 'rook',
      kicker: 'IV — The Old Laws',
      title: 'What four centuries of masters knew.',
      lede: 'Control the center. Develop before you attack. Guard the king.',
      body: [
        'Every generation states them differently, but the laws endure. The Romantics broke the second law on purpose, with spectacular results — and even Anderssen castled when he could.',
      ],
    },
    {
      id: 'pieces',
      piece: 'bishop',
      kicker: 'V — The Anatomy of Every Piece',
      title: 'Six characters. One language.',
      lede: 'Victory asks you to master each warrior’s kinetic rules, point value and positional temperament.',
      body: [
        'Each piece moves by its own geometry, and each has a temperament to match. Learn what they are worth, where they belong, and what they will never do.',
      ],
    },
    {
      id: 'phases',
      piece: 'king',
      kicker: 'VI — The Three Phases of Play',
      title: 'Opening. Middlegame. Endgame.',
      lede: 'A game of chess is three games in one, each with its own currency.',
      body: [
        'Forces gather, collide, and then dissolve. The player who understands which phase they are standing in usually wins it.',
      ],
    },
    {
      id: 'legacy',
      piece: 'pawn',
      kicker: 'VII — The Unbroken Dialogue',
      title: 'The board is still waiting.',
      lede: 'From Gupta India to neural networks, chess has never stopped being played.',
      body: [
        'Chess is civilization’s oldest unbroken dialogue of geometry, sacrifice, and willpower. The pieces have changed names, the queen has grown stronger, the analysis has moved from café tables to silicon — but the board is still sixty-four squares, and it is still waiting for your first move.',
      ],
    },
  ],
  laws: [
    {
      title: 'Control the Center',
      tag: 'Center Dominance',
      text: 'The four central squares (e4, d4, e5, d5) are high ground. Pieces deployed toward the hub radiate influence across both wings like artillery on a ridge.',
    },
    {
      title: 'Develop Before Attack',
      tag: 'Tempo & Mobilization',
      text: 'Knights before bishops. Mobilize minor pieces before launching reckless queen incursions. An army attacking with two units against four defenders is doomed to stall.',
    },
    {
      title: 'Guard King Sanctity',
      tag: 'Monarch Survival',
      text: 'Castle early, keep your protective pawn fortress unprovoked, and never leave your monarch in an open center file where heavy pieces can converge.',
    },
  ],
  pieces: [
    {
      id: 'pawn',
      name: 'Pawn',
      label: 'Infantry',
      value: '1',
      abilityLabel: 'Special ability',
      ability: 'Promotion to Queen (8th rank)',
      body: 'Moves one square forward, or two on its opening stride; captures one square diagonally forward. The soul of chess: pawns cannot step backward, and so they dictate the permanent terrain of the board.',
      moveType: 'pawn',
    },
    {
      id: 'knight',
      name: 'Knight',
      label: 'Cavalry',
      value: '3',
      abilityLabel: 'Tactical power',
      ability: 'The multi-fork attack',
      body: 'The sole piece able to leap over friendly or enemy units. Moves in an L-shape: two squares orthogonally, then one square perpendicular. Supreme in closed, crowded positions.',
      moveType: 'jump',
      offsets: [
        [1, 2], [2, 1], [2, -1], [1, -2],
        [-1, -2], [-2, -1], [-2, 1], [-1, 2],
      ],
    },
    {
      id: 'bishop',
      name: 'Bishop',
      label: 'Sniper',
      value: '3',
      abilityLabel: 'Tactical power',
      ability: 'Long-range skewers & pins',
      body: 'Moves any distance along open diagonals, permanently bound to the color square on which it began life. A pair of bishops working in tandem can dominate open vistas of the board.',
      moveType: 'slide',
      directions: [[1, 1], [1, -1], [-1, 1], [-1, -1]],
    },
    {
      id: 'rook',
      name: 'Rook',
      label: 'Siege Tower',
      value: '5',
      abilityLabel: 'Special ability',
      ability: 'Castling with the King',
      body: 'Moves any distance along horizontal ranks and vertical files. Heavy artillery that comes alive once the files are cleared of pawns. Deadly when invading the enemy’s seventh rank.',
      moveType: 'slide',
      directions: [[1, 0], [-1, 0], [0, 1], [0, -1]],
    },
    {
      id: 'queen',
      name: 'Queen',
      label: 'Imperator',
      value: '9',
      abilityLabel: 'Golden rule',
      ability: 'Never deploy too early',
      body: 'The lethal fusion of rook and bishop. Moves any number of squares in any direction — rank, file or diagonal. The most destructive attacking weapon on the sixty-four squares.',
      moveType: 'slide',
      directions: [
        [1, 0], [-1, 0], [0, 1], [0, -1],
        [1, 1], [1, -1], [-1, 1], [-1, -1],
      ],
    },
    {
      id: 'king',
      name: 'King',
      label: 'Sovereign',
      value: '∞',
      abilityLabel: 'Supreme law',
      ability: 'Checkmate ends the world',
      body: 'Moves one square in any direction and cannot step into attack. If trapped with no legal escape while attacked, the game ends in checkmate. In the endgame, the king transforms into an active fighter.',
      moveType: 'step',
      offsets: [
        [-1, -1], [0, -1], [1, -1],
        [-1, 0], [1, 0],
        [-1, 1], [0, 1], [1, 1],
      ],
    },
  ],
  phases: [
    {
      phase: 'The Opening',
      text: 'The first 10–15 moves. Focus purely on occupation of central squares, rapid mobilization of knights and bishops, and castling the king to safety before initiating combat.',
    },
    {
      phase: 'The Middlegame',
      text: 'Forces collide. Formulation of grand plans, pawn breaks, tactical combinations — pins, forks, skewers, sacrifices — and fighting for open files for your rooks.',
    },
    {
      phase: 'The Endgame',
      text: 'Queens and major armies are traded off. The remaining pawns march toward promotion, and the once-sheltered king emerges from hiding to command the center.',
    },
  ],
  immortal: {
    moments: [
      {
        move: '2. f4',
        title: 'The King’s Gambit Unfurled',
        text: 'Anderssen flings his f-pawn into Black’s jaws, offering material purely to deflect the e5-pawn and crack open the f-file for the future rook.',
      },
      {
        move: '3... Qh4+',
        title: 'The Royal Interruption',
        text: 'Black’s queen strikes along the weakened e1–h4 diagonal and puts White in check, stripping Anderssen of the right to castle.',
      },
      {
        move: '18. Bd6!',
        title: 'The Bishop Guillotine',
        text: 'A bishop lands in the heart of Black’s camp, severing the queen from the defense of her back ranks. Anderssen consciously leaves both corner rooks unguarded — ten points of material offered for inescapable coordinate control.',
      },
      {
        move: '20... Qxa1',
        title: 'Both Rooks Sacrificed',
        text: 'Kieseritzky has devoured both white rooks and stands an astronomical +13 in material. But chess is decided by checkmate, not by ledger balance.',
      },
      {
        move: '22. Qf6+!',
        title: 'The Crown Thrown Into the Dust',
        text: 'The grand crescendo. Anderssen offers his own queen at point-blank range. Black’s knight is forced to capture, vacating its guard of the critical e7 square.',
      },
      {
        move: '23. Be7#',
        title: 'Pure Geometric Checkmate',
        text: 'The black king is hopelessly trapped: d7 sealed by a pawn, e8 and f8 attacked by the white bishop and knights. Mate with only a bishop and two minor knights.',
      },
    ],
    quote:
      'The Queen is sacrificed so the three remaining minor pieces can weave an unbreakable geometric noose.',
    legacy:
      'Upon seeing this mate, players in the London café rose in standing applause and showered the table with gold coins, dubbing it forever “The Immortal Game”.',
    pgn: `[Event "London"]
[Site "London"]
[Date "1851.06.21"]
[Round "?"]
[White "Adolf Anderssen"]
[Black "Lionel Kieseritzky"]
[Result "1-0"]
[ECO "C33"]

1. e4 e5 2. f4 exf4 3. Bc4 Qh4+ 4. Kf1 b5 5. Bxb5 Nf6 6. Nf3 Qh6 7. d3 Nh5 8. Nh4 Qg5 9. Nf5 c6 10. g4 Nf6 11. Rg1 cxb5 12. h4 Qg6 13. h5 Qg5 14. Qf3 Ng8 15. Bxf4 Qf6 16. Nc3 Bc5 17. Nd5 Qxb2 18. Bd6 Bxg1 19. e5 Qxa1+ 20. Ke2 Na6 21. Nxg7+ Kd8 22. Qf6+ Nxf6 23. Be7# 1-0`,
  },
};
